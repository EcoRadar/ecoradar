package com.example.ecoradartest2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;

public class PreviewActivity extends AppCompatActivity {

    private ImageView imagePreview;
    private ImageButton backButton;
    private Button nextButton;
    private Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);

        imagePreview = findViewById(R.id.imagePreview);
        backButton = findViewById(R.id.backButton);
        nextButton = findViewById(R.id.nextButton);

        String imageUriString = getIntent().getStringExtra("imageUri");
        if (imageUriString != null) {
            imageUri = Uri.parse(imageUriString);
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                imagePreview.setImageBitmap(bitmap);
            } catch (Exception e) {
                Log.e("PreviewActivity", "Failed to load image preview", e);
            }
        } else {
            Log.e("PreviewActivity", "No image URI found in intent");
        }

        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(PreviewActivity.this, CameraActivity.class);
            startActivity(intent);
            finish();
        });

        // ✅ Go to map for location selection
        nextButton.setOnClickListener(v -> {
            if (imageUri != null) {
                Intent intent = new Intent(PreviewActivity.this, Maps.class);
                intent.putExtra("imageUri", imageUri.toString());
                startActivity(intent);
                // ❌ Remove finish() here
            } else {
                Log.e("PreviewActivity", "Cannot proceed, imageUri is null");
            }
        });
    }
}
