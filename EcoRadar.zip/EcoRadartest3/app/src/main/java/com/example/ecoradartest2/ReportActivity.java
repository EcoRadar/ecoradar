package com.example.ecoradartest2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class ReportActivity extends AppCompatActivity {

    private ImageView imagePreview;
    private Button addImageButton, submitButton;
    private EditText categoryField, severityField, descriptionField;
    private TextView locationText;
    private Uri imageUri;
    private FirebaseFirestore firestore;
    private StorageReference storageRef;
    private FirebaseAuth auth;

    private double latitude = 0.0;
    private double longitude = 0.0;

    private static final int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        // Initialize Firebase
        firestore = FirebaseFirestore.getInstance();
        storageRef = FirebaseStorage.getInstance().getReference();
        auth = FirebaseAuth.getInstance();

        // UI components
        imagePreview = findViewById(R.id.imagePreview);
        addImageButton = findViewById(R.id.addImageButton);
        submitButton = findViewById(R.id.submitButton);
        categoryField = findViewById(R.id.categoryField);
        severityField = findViewById(R.id.severityField);
        descriptionField = findViewById(R.id.descriptionField);
        locationText = findViewById(R.id.locationText);
        ImageButton backButton = findViewById(R.id.backButton);

        // Back button → return to previous screen
        backButton.setOnClickListener(v -> finish());

        // 🗺️ Get location from Maps
        latitude = getIntent().getDoubleExtra("latitude", 0.0);
        longitude = getIntent().getDoubleExtra("longitude", 0.0);
        if (latitude != 0.0 && longitude != 0.0) {
            locationText.setText(String.format("Lat: %.5f, Lng: %.5f", latitude, longitude));
        } else {
            locationText.setText("Location not available");
        }

        // 📸 Get image URI from intent
        String imageUriString = getIntent().getStringExtra("imageUri");
        if (imageUriString != null) {
            imageUri = Uri.parse(imageUriString);
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                imagePreview.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Select a new image manually (optional)
        addImageButton.setOnClickListener(v -> openImageChooser());

        // Upload report to Firebase
        submitButton.setOnClickListener(v -> uploadReport());
    }

    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                imagePreview.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void uploadReport() {
        if (imageUri == null) {
            Toast.makeText(this, "Please select an image.", Toast.LENGTH_SHORT).show();
            return;
        }

        String category = categoryField.getText().toString().trim();
        String severity = severityField.getText().toString().trim();
        String description = descriptionField.getText().toString().trim();

        if (category.isEmpty() || severity.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        FirebaseUser currentUser = auth.getCurrentUser();
        String userId = (currentUser != null) ? currentUser.getUid() : "test";

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Uploading Report...");
        progressDialog.show();

        String imageName = "reports/" + UUID.randomUUID().toString();
        StorageReference imageRef = storageRef.child(imageName);

        imageRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> imageRef.getDownloadUrl().addOnSuccessListener(uri -> {

                    // 🕒 Create readable timestamp (like your example)
                    SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy 'at' hh:mm:ss a 'UTC+8'", Locale.getDefault());
                    String readableTimestamp = sdf.format(new Date());

                    Map<String, Object> report = new HashMap<>();
                    report.put("category", category);
                    report.put("severity", severity);
                    report.put("description", description);
                    report.put("latitude", latitude);
                    report.put("longitude", longitude);
                    report.put("imageUrl", uri.toString());
                    report.put("timestamp", readableTimestamp);
                    report.put("userId", userId);

                    firestore.collection("Reports")
                            .add(report)
                            .addOnSuccessListener(documentReference -> {
                                progressDialog.dismiss();
                                Toast.makeText(this, "Report submitted successfully!", Toast.LENGTH_SHORT).show();
                                finish();
                            })
                            .addOnFailureListener(e -> {
                                progressDialog.dismiss();
                                Toast.makeText(this, "Error submitting report: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            });
                }))
                .addOnFailureListener(e -> {
                    progressDialog.dismiss();
                    Toast.makeText(this, "Image upload failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                })
                .addOnProgressListener(snapshot -> {
                    double progress = (100.0 * snapshot.getBytesTransferred() / snapshot.getTotalByteCount());
                    progressDialog.setMessage("Uploaded " + (int) progress + "%");
                });
    }
}
