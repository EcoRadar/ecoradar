package com.example.ecoradartest2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Register2 extends AppCompatActivity {

    private static final String TAG = "Register2";

    EditText editTextEmail, editTextPassword, editTextUsername, editTextPhone;
    Button buttonRegister;

    FirebaseAuth mAuth = FirebaseAuth.getInstance();
    FirebaseFirestore db = FirebaseFirestore.getInstance();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register2);

        editTextEmail = findViewById(R.id.email);
        editTextPassword = findViewById(R.id.password);
        editTextUsername = findViewById(R.id.username);
        editTextPhone = findViewById(R.id.phone);
        buttonRegister = findViewById(R.id.registerButton);

        buttonRegister.setOnClickListener(v -> {
            String email = editTextEmail.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();
            String username = editTextUsername.getText().toString().trim();
            String phone = editTextPhone.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty() || username.isEmpty() || phone.isEmpty()) {
                Toast.makeText(Register2.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                registerUser(email, password, username, phone);
            }
        });
    }

    private void registerUser(String email, String password, String username, String phone) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();

                        if (user != null) {
                            Map<String, Object> userData = new HashMap<>();
                            userData.put("username", username);
                            userData.put("phone", phone);
                            userData.put("email", email);
                            userData.put("role", "user"); // 👈 default role
                            userData.put("createdAt", Timestamp.now()); // 👈 time of registration

                            db.collection("users").document(user.getUid())
                                    .set(userData)
                                    .addOnSuccessListener(aVoid -> {
                                        Log.d(TAG, "User profile saved for: " + user.getUid());
                                    })
                                    .addOnFailureListener(e -> {
                                        Log.w(TAG, "Error saving user profile", e);
                                    });
                        }

                        updateUI(user);
                    } else {
                        Toast.makeText(Register2.this,
                                "Authentication failed: " + task.getException().getMessage(),
                                Toast.LENGTH_SHORT).show();
                        updateUI(null);
                    }
                });
    }

    private void updateUI(FirebaseUser user) {
        if (user != null) {
            Toast.makeText(this, "Welcome " + user.getEmail(), Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(Register2.this, MainMenu.class);
            startActivity(intent);
            finish();
        }
    }
}
