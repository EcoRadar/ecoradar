package com.example.EcoRadar;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;

import java.util.ArrayList;

public class ImagesAdapter extends RecyclerView.Adapter<ImagesAdapter.ViewHolder> {

    private final ArrayList<Uri> imageUris;

    public ImagesAdapter(ArrayList<Uri> imageUris) {

        this.imageUris = new ArrayList<>(imageUris);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_photo, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Uri uri = imageUris.get(position);


        Glide.with(holder.itemView.getContext())
                .load(uri)
                .centerCrop()
                .placeholder(R.drawable.baseline_user)
                .error(R.drawable.error)
                .transition(DrawableTransitionOptions.withCrossFade())
                .into(holder.reportImageThumb);


        holder.btnRemoveImage.setOnClickListener(v -> {
            int adapterPosition = holder.getAdapterPosition();
            if (adapterPosition != RecyclerView.NO_POSITION) {
                imageUris.remove(adapterPosition);
                notifyItemRemoved(adapterPosition);
                notifyItemRangeChanged(adapterPosition, imageUris.size());
            }
        });


        holder.reportImageThumb.setOnClickListener(v -> {

        });
    }

    @Override
    public int getItemCount() {
        return imageUris.size();
    }


    public ArrayList<Uri> getImages() {
        return new ArrayList<>(imageUris);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView reportImageThumb;
        ImageButton btnRemoveImage;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            reportImageThumb = itemView.findViewById(R.id.reportImageThumb);
            btnRemoveImage = itemView.findViewById(R.id.btnRemoveImage);
        }
    }
}
