package com.example.EcoRadar;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HomeFragment extends Fragment {

    private FirebaseFirestore db;
    private List<Report> reportList;
    private ReportAdapter adapter;
    private RecyclerView recyclerReports;
    private String currentUserId;
    private ListenerRegistration reportsListener;

    public HomeFragment() {}

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_home, container, false);

        db = FirebaseFirestore.getInstance();

        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            return view;
        }

        currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        recyclerReports = view.findViewById(R.id.recyclerReports);
        recyclerReports.setLayoutManager(new LinearLayoutManager(getContext()));

        reportList = new ArrayList<>();
        adapter = new ReportAdapter(getContext(), reportList);
        recyclerReports.setAdapter(adapter);

        startRealtimeUpdates();

        return view;
    }

    private void startRealtimeUpdates() {

        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;

        if (reportsListener != null) {
            reportsListener.remove();
        }

        reportsListener = db.collection("Reports")
                .whereEqualTo("userId", currentUserId)
                .whereIn("status", Arrays.asList("Pending", "In Review"))
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) -> {

                    if (getContext() == null) return;

                    if (error != null) {
                        Log.e("HomeFragment", "Realtime listener error", error);
                        return;
                    }

                    if (value == null) return;

                    for (DocumentChange dc : value.getDocumentChanges()) {
                        Report report = dc.getDocument().toObject(Report.class);
                        report.setDocumentId(dc.getDocument().getId());

                        switch (dc.getType()) {
                            case ADDED:
                                adapter.addReport(report);
                                break;

                            case MODIFIED:
                                adapter.updateReport(report);
                                break;

                            case REMOVED:
                                adapter.removeReport(report.getDocumentId());
                                break;
                        }
                    }
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (reportsListener != null) {
            reportsListener.remove();
            reportsListener = null;
        }
    }
}
