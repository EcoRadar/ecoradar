package com.example.EcoRadar;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.ViewHolder> {

    private final ArrayList<NotificationModel> notifications;
    private final OnDeleteClick listener;

    public interface OnDeleteClick {
        void onDelete(String notifId);
    }

    public NotificationsAdapter(ArrayList<NotificationModel> notifications, OnDeleteClick listener) {
        this.notifications = notifications;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_notification, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        NotificationModel notif = notifications.get(position);

        holder.txtMessage.setText(notif.getMessage());

        if (notif.getTimestamp() != null) {
            String time = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                    .format(notif.getTimestamp().toDate());
            holder.txtTimestamp.setText(time);
        }

        holder.btnDelete.setOnClickListener(v -> {
            if (notif.getId() != null) {
                listener.onDelete(notif.getId());
                notifications.remove(position);
                notifyItemRemoved(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return notifications.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtMessage, txtTimestamp;
        ImageButton btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtMessage = itemView.findViewById(R.id.notification_message);
            txtTimestamp = itemView.findViewById(R.id.notification_timestamp);
            btnDelete = itemView.findViewById(R.id.btnDeleteNotif);
        }
    }
}
