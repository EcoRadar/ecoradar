package com.example.EcoRadar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CustomInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {

    private final View window;
    private final Context context;

    public CustomInfoWindowAdapter(Context context) {
        this.context = context;
        window = LayoutInflater.from(context).inflate(R.layout.item_info_window, null);
    }

    @Override
    public View getInfoWindow(@NonNull Marker marker) {
        renderWindow(marker, window);
        return window;
    }

    @Override
    public View getInfoContents(@NonNull Marker marker) {

        return null;
    }

    @SuppressWarnings("unchecked")
    private void renderWindow(Marker marker, View view) {
        if (marker == null || marker.getTag() == null) return;


        Map<String, Object> data;
        try {
            data = (Map<String, Object>) marker.getTag();
        } catch (ClassCastException e) {
            e.printStackTrace();
            return;
        }


        String category = data.get("category") instanceof String ? (String) data.get("category") : "No Category";
        String severity = data.get("severity") instanceof String ? (String) data.get("severity") : "N/A";
        String description = data.get("description") instanceof String ? (String) data.get("description") : "";
        List<String> imageUrls = data.get("imageUrls") instanceof List ? (List<String>) data.get("imageUrls") : new ArrayList<>();


        TextView title = view.findViewById(R.id.info_title);
        TextView sev = view.findViewById(R.id.info_severity);
        TextView snippet = view.findViewById(R.id.info_snippet);

        if (title != null) title.setText(category);
        if (sev != null) sev.setText("Severity: " + severity);
        if (snippet != null) snippet.setText(description);


        RecyclerView recyclerView = view.findViewById(R.id.info_image_recycler);
        if (recyclerView != null) {
            recyclerView.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
            ReportImagesAdapter adapter = new ReportImagesAdapter(context, imageUrls);
            recyclerView.setAdapter(adapter);
        }
    }
}
