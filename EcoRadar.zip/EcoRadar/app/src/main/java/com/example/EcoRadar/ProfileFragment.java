package com.example.EcoRadar;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class ProfileFragment extends Fragment {

    private ImageView profileImage;
    private TextView userName, userEmail;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    public ProfileFragment() {}

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);


        try {
            AppCompatActivity activity = (AppCompatActivity) requireActivity();
            if (activity.getSupportActionBar() != null) {
                activity.getSupportActionBar().hide();
            }
        } catch (Exception ignored) {}


        requireActivity().getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
        );


        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();


        profileImage = view.findViewById(R.id.profileImage);
        userName = view.findViewById(R.id.userName);
        userEmail = view.findViewById(R.id.userEmail);


        loadUserInfo();


        view.setAlpha(0f);
        view.animate().alpha(1f).setDuration(300).start();

        return view;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();


        try {
            AppCompatActivity activity = (AppCompatActivity) requireActivity();
            if (activity.getSupportActionBar() != null) {
                activity.getSupportActionBar().show();
            }
        } catch (Exception ignored) {}

        requireActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    private void safeToast(String message) {
        if (isAdded()) {
            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
        }
    }

    private void loadUserInfo() {
        try {
            FirebaseUser user = mAuth.getCurrentUser();
            if (user == null) {
                safeToast("User not logged in");
                return;
            }

            db.collection("users")
                    .document(user.getUid())
                    .get()
                    .addOnSuccessListener(doc -> {
                        if (!isAdded()) return;

                        if (doc.exists()) {
                            String name = doc.getString("username");
                            String email = doc.getString("email");

                            userName.setText(name != null ? name : "User Name");
                            userEmail.setText(email != null ? email : user.getEmail());
                        }


                        if (isAdded()) {
                            if (user.getPhotoUrl() != null) {
                                Glide.with(requireContext())
                                        .load(user.getPhotoUrl())
                                        .placeholder(R.drawable.user_placeholder)
                                        .circleCrop()
                                        .into(profileImage);
                            } else {
                                profileImage.setImageResource(R.drawable.user_placeholder);
                            }
                        }
                    })
                    .addOnFailureListener(e -> safeToast("Failed to load user info"));

        } catch (Exception e) {
            Log.e("ProfileFragment", "loadUserInfo() error", e);
        }
    }
}
