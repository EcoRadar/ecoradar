package com.example.EcoRadar;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import android.widget.TextView;

import java.util.List;

public class ReportBottomSheet extends BottomSheetDialog {

    public ReportBottomSheet(@NonNull Context context,
                             String category,
                             String severity,
                             String description,
                             List<String> imageUrls) {
        super(context);
        setContentView(createView(context, category, severity, description, imageUrls));
    }

    private View createView(Context context,
                            String category,
                            String severity,
                            String description,
                            List<String> imageUrls) {
        View view = LayoutInflater.from(context).inflate(R.layout.bottomsheet_report, null);

        TextView tvCategory = view.findViewById(R.id.tv_category);
        TextView tvSeverity = view.findViewById(R.id.tv_severity);
        TextView tvDescription = view.findViewById(R.id.tv_description);
        RecyclerView recyclerView = view.findViewById(R.id.images_recycler);

        tvCategory.setText(category);
        tvSeverity.setText(severity);
        tvDescription.setText(description);


        recyclerView.setLayoutManager(
                new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
        recyclerView.setAdapter(new ReportImagesAdapter(context, imageUrls));

        return view;
    }
}
