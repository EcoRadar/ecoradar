package com.example.EcoRadar;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Thankyouscreen extends AppCompatActivity {

    private RecyclerView recyclerImages;
    private TextView textCategory, textSeverity, textLocation;
    private ImageView closeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thankyouscreen);

        recyclerImages = findViewById(R.id.recyclerImages);
        textCategory = findViewById(R.id.textCategory);
        textSeverity = findViewById(R.id.textSeverity);
        textLocation = findViewById(R.id.textLocation);
        closeButton = findViewById(R.id.closeButton);

        Intent intent = getIntent();
        String category = intent.getStringExtra("category");
        String severity = intent.getStringExtra("severity");
        String location = intent.getStringExtra("location");
        ArrayList<String> urls = intent.getStringArrayListExtra("imageUrls");

        textCategory.setText("Category: " + (category != null ? category : "N/A"));
        textSeverity.setText("Severity: " + (severity != null ? severity : "N/A"));
        textLocation.setText("Location: " + (location != null ? location : "Not available"));


        if (urls == null || urls.isEmpty()) {
            urls = new ArrayList<>();
            urls.add("placeholder");
        }

        recyclerImages.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        );

        recyclerImages.setAdapter(new ReportImagesAdapter(
                this,
                urls
        ));


        closeButton.setOnClickListener(v -> {
            startActivity(new Intent(Thankyouscreen.this, MainMenu.class));
            finish();
        });
    }
}
