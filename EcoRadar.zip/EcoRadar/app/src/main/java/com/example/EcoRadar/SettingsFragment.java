package com.example.EcoRadar;

import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class SettingsFragment extends Fragment {

    private TextView txtUsername, txtEmail;
    private Switch notificationSwitch;
    private ImageView backBtn;
    private View btnContactSupport;

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    public SettingsFragment() {}

    public static SettingsFragment newInstance() {
        return new SettingsFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_settings, container, false);


        txtUsername = view.findViewById(R.id.txtUsername);
        txtEmail = view.findViewById(R.id.txtEmail);
        notificationSwitch = view.findViewById(R.id.notificationSwitch);
        backBtn = view.findViewById(R.id.backBtn);
        btnContactSupport = view.findViewById(R.id.btnContactSupport);


        backBtn.setOnClickListener(v -> requireActivity().onBackPressed());


        btnContactSupport.setOnClickListener(v -> {
            requireActivity()
                    .getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.main_container, new ContactSupportFragment())
                    .addToBackStack(null)
                    .commit();
        });


        boolean isEnabled = requireActivity()
                .getSharedPreferences("settings", getContext().MODE_PRIVATE)
                .getBoolean("notifications", true);

        notificationSwitch.setChecked(isEnabled);

        notificationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            requireActivity()
                    .getSharedPreferences("settings", getContext().MODE_PRIVATE)
                    .edit()
                    .putBoolean("notifications", isChecked)
                    .apply();
        });


        loadUserData();

        return view;
    }

    private void loadUserData() {
        FirebaseUser currentUser = auth.getCurrentUser();

        if (currentUser == null) {
            txtUsername.setText("Guest");
            txtEmail.setText("Not logged in");
            return;
        }

        String userId = currentUser.getUid();

        txtEmail.setText(currentUser.getEmail());

        db.collection("users")
                .document(userId)
                .get()
                .addOnSuccessListener(document -> {
                    if (document.exists()) {
                        String username = document.getString("username");
                        txtUsername.setText(
                                username != null && !username.isEmpty()
                                        ? username
                                        : "Unknown User"
                        );
                    } else {
                        txtUsername.setText("Unknown User");
                    }
                })
                .addOnFailureListener(e -> txtUsername.setText("Error loading"));
    }
}
