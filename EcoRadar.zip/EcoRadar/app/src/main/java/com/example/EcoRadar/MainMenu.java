package com.example.EcoRadar;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.Intent;
import androidx.core.view.GravityCompat;


public class MainMenu extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private static final int LOCATION_PERMISSION_REQUEST = 101;
    private static final int APP_SETTINGS_REQUEST = 102;

    private DrawerLayout drawerLayout;
    private FragmentManager fragmentManager;

    private ImageButton btnMenu, navHome, navMap;
    private ImageView btnLocation, navNotifications;
    private LinearLayout topHeader;


    private View navNotificationBadge;

    private final int HEADER_DP = 40;
    private final int BOTTOM_NAV_DP = 70;
    private final boolean immersive = true;


    private final BroadcastReceiver notificationReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (navNotificationBadge != null) {
                navNotificationBadge.setVisibility(View.VISIBLE);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_main);

        if (immersive) enableImmersiveMode();

        drawerLayout = findViewById(R.id.drawer_layout);
        fragmentManager = getSupportFragmentManager();
        topHeader = findViewById(R.id.top_header);

        setupDrawer();
        setupNavigationButtons();


        openFragment(new HomeFragment());
        showTopHeader(true);


        updateBottomNavSelection(navHome);
    }

    private void setupDrawer() {
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, R.string.open_nav, R.string.close_nav);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    private void setupNavigationButtons() {
        btnMenu = findViewById(R.id.btn_menu);
        navHome = findViewById(R.id.nav_home);
        navMap = findViewById(R.id.nav_map);
        navNotifications = findViewById(R.id.nav_notifications);
        btnLocation = findViewById(R.id.btn_location);


        navNotificationBadge = findViewById(R.id.nav_notification_badge);

        btnMenu.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));

        navHome.setOnClickListener(v -> {
            updateBottomNavSelection(navHome);
            showTopHeader(true);
            openFragment(new HomeFragment());
        });

        navMap.setOnClickListener(v -> {
            updateBottomNavSelection(navMap);
            showTopHeader(true);
            openFragment(new MapsFragment());
        });

        navNotifications.setOnClickListener(v -> {
            showTopHeader(true);
            openFragment(new NotificationsFragment());


            if (navNotificationBadge != null) {
                navNotificationBadge.setVisibility(View.GONE);
            }
        });

        btnLocation.setOnClickListener(v -> checkAndOpenMap());
    }


    private void updateBottomNavSelection(ImageButton selectedButton) {
        navHome.setSelected(false);
        navMap.setSelected(false);
        selectedButton.setSelected(true);
    }


    private void checkAndOpenMap() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            startMapsActivity();
        } else if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.ACCESS_FINE_LOCATION)) {

            Toast.makeText(this, "Location permission is required to select your location.", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.fromParts("package", getPackageName(), null));
            startActivityForResult(intent, APP_SETTINGS_REQUEST);

        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST);
        }
    }

    private void startMapsActivity() {
        startActivity(new Intent(this, Maps.class));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startMapsActivity();
            } else {
                Toast.makeText(this, "Location permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == APP_SETTINGS_REQUEST) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission granted! Opening map...", Toast.LENGTH_SHORT).show();
                startMapsActivity();
            } else {
                Toast.makeText(this, "Location permission not granted.", Toast.LENGTH_SHORT).show();
            }
        }
    }


    private void openFragment(Fragment fragment) {
        FragmentTransaction ft = fragmentManager.beginTransaction();
        ft.setReorderingAllowed(true);
        ft.replace(R.id.main_container, fragment);
        ft.commitAllowingStateLoss();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            updateBottomNavSelection(navHome);
            showTopHeader(true);
            openFragment(new HomeFragment());

        } else if (id == R.id.nav_settings) {
            showTopHeader(true);
            openFragment(new SettingsFragment());

        } else if (id == R.id.nav_about) {
            showTopHeader(true);
            openFragment(new AboutFragment());

        } else if (id == R.id.nav_hotlines) {
            showTopHeader(true);
            openFragment(new HotlinesFragment());

        } else if (id == R.id.nav_logout) {
            showLogoutConfirmation();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    private void showLogoutConfirmation() {
        View view = getLayoutInflater().inflate(R.layout.logout_confirmation, null);
        Button btnYes = view.findViewById(R.id.btnYes);
        Button btnCancel = view.findViewById(R.id.btnCancel);

        androidx.appcompat.app.AlertDialog dialog =
                new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setView(view)
                        .setCancelable(true)
                        .create();

        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        btnYes.setOnClickListener(v -> {
            dialog.dismiss();
            logoutUser();
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void logoutUser() {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(this, LogIn.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }


    private void showTopHeader(boolean show) {
        if (topHeader != null) topHeader.setVisibility(show ? View.VISIBLE : View.GONE);

        View container = findViewById(R.id.main_container);
        if (container != null) {
            ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) container.getLayoutParams();

            int headerPx = dpToPx(HEADER_DP);
            params.topMargin = headerPx + getStatusBarHeight();
            params.bottomMargin = getNavigationBarHeight();

            container.setLayoutParams(params);
        }
    }

    private void enableImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController controller = getWindow().getInsetsController();

            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }

        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    private int getStatusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : 0;
    }

    private int getNavigationBarHeight() {
        int id = getResources().getIdentifier("navigation_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : 0;
    }


    @Override
    protected void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(notificationReceiver, new IntentFilter("NEW_NOTIFICATION"));
    }

    @Override
    protected void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this)
                .unregisterReceiver(notificationReceiver);
    }
}
