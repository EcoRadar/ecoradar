package com.example.EcoRadar;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import android.location.Geocoder;
import android.location.Address;


public class ReportActivity extends AppCompatActivity {

    private LinearLayout imageListContainer;
    private FrameLayout imageSlotTemplate;
    private ArrayList<Uri> imageUris = new ArrayList<>();
    private Uri currentImageUri;

    private EditText descriptionField, otherCategoryField;
    private androidx.appcompat.widget.AppCompatAutoCompleteTextView categoryField, severityField;
    private TextView locationText;
    private ImageButton backButton;
    private MaterialButton submitButton;

    private FirebaseFirestore firestore;
    private StorageReference storageRef;
    private FirebaseAuth auth;

    private double latitude = 0.0, longitude = 0.0;

    private ActivityResultLauncher<Uri> takePictureLauncher;
    private ActivityResultLauncher<String> galleryLauncher;
    private ActivityResultLauncher<String> requestCameraPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        firestore = FirebaseFirestore.getInstance();
        storageRef = FirebaseStorage.getInstance().getReference();
        auth = FirebaseAuth.getInstance();

        imageListContainer = findViewById(R.id.imageListContainer);
        imageSlotTemplate = findViewById(R.id.imageSlotTemplate);
        categoryField = findViewById(R.id.categoryDropdown);
        severityField = findViewById(R.id.severityDropdown);
        descriptionField = findViewById(R.id.descriptionField);
        otherCategoryField = findViewById(R.id.otherCategoryField);
        locationText = findViewById(R.id.locationValue);
        backButton = findViewById(R.id.backButton);
        submitButton = findViewById(R.id.submitButton);

        setupDropdowns();
        setupLocation();
        setupImages();
        setupLaunchers();

        submitButton.setOnClickListener(v -> uploadReport());
        backButton.setOnClickListener(v -> onBackPressed());
    }

    private void setupDropdowns() {
        String[] categories = {"Flooding", "Illegal Dumping", "Air Pollution", "Water Pollution",
                "Deforestation", "Forest Fire", "Landslide", "Oil Spill",
                "Sewage Leak", "Chemical Spill", "Dead Wildlife",
                "Illegal Logging", "Noise Pollution", "Open Burning",
                "Plastic Waste", "Other (Specify)"};

        String[] severities = {"Low", "Medium", "High"};

        categoryField.setAdapter(new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, categories));
        severityField.setAdapter(new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, severities));

        categoryField.setOnClickListener(v -> categoryField.showDropDown());
        severityField.setOnClickListener(v -> severityField.showDropDown());

        categoryField.setOnItemClickListener((parent, view, position, id) -> {
            String selected = categoryField.getText().toString();
            otherCategoryField.setVisibility(selected.equals("Other (Specify)") ? View.VISIBLE : View.GONE);
            if (!selected.equals("Other (Specify)")) otherCategoryField.setText("");
        });
    }

    private void setupLocation() {
        latitude = getIntent().getDoubleExtra("latitude", 0.0);
        longitude = getIntent().getDoubleExtra("longitude", 0.0);
        locationText.setText(getIntent().getStringExtra("address") != null
                ? getIntent().getStringExtra("address") : "Location not available");
    }

    private void setupImages() {
        ArrayList<String> passedUris = getIntent().getStringArrayListExtra("imageUris");
        if (passedUris != null) {
            for (String s : passedUris) addImage(Uri.parse(s));
        }

        imageSlotTemplate.setOnClickListener(v -> showImageSourceDialog());
    }

    private void setupLaunchers() {
        takePictureLauncher = registerForActivityResult(
                new ActivityResultContracts.TakePicture(),
                success -> {
                    if (success && currentImageUri != null) addImage(currentImageUri);
                    else Toast.makeText(this, "Photo not saved", Toast.LENGTH_SHORT).show();
                }
        );

        requestCameraPermissionLauncher =
                registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                    if (isGranted) {
                        try {
                            createTempImageAndLaunchCamera();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show();
                    }
                });

        galleryLauncher = registerForActivityResult(
                new ActivityResultContracts.GetMultipleContents(),
                uris -> {
                    if (uris != null && !uris.isEmpty()) {
                        for (Uri uri : uris) addImage(uri);
                    }
                }
        );
    }

    private void showImageSourceDialog() {
        androidx.appcompat.app.AlertDialog.Builder dialog =
                new androidx.appcompat.app.AlertDialog.Builder(this);

        dialog.setTitle("Select Image Source");
        dialog.setItems(new CharSequence[]{"Take Photo", "Choose from Gallery"}, (d, which) -> {
            if (which == 0) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                        == PackageManager.PERMISSION_GRANTED) {
                    try {
                        createTempImageAndLaunchCamera();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA);
                }
            } else {
                galleryLauncher.launch("image/*");
            }
        });
        dialog.show();
    }

    private void addImage(Uri uri) {
        imageUris.add(uri);

        View imageViewLayout = LayoutInflater.from(this)
                .inflate(R.layout.item_photo, imageListContainer, false);

        ImageView thumb = imageViewLayout.findViewById(R.id.reportImageThumb);
        ImageButton remove = imageViewLayout.findViewById(R.id.btnRemoveImage);

        Glide.with(this).load(uri).centerCrop().into(thumb);

        remove.setOnClickListener(v -> {
            imageUris.remove(uri);
            imageListContainer.removeView(imageViewLayout);
        });

        int insertIndex = Math.max(0, imageListContainer.getChildCount() - 1);
        imageListContainer.addView(imageViewLayout, insertIndex);
    }

    private void createTempImageAndLaunchCamera() throws IOException {
        File imageFile = createImageFile();
        currentImageUri = FileProvider.getUriForFile(this, getPackageName() + ".provider", imageFile);
        takePictureLauncher.launch(currentImageUri);
    }

    private File createImageFile() throws IOException {
        String timeStamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                .format(new Date());

        String fileName = "JPEG_" + timeStamp + "_";
        File storageDir = new File(getExternalFilesDir(null), "Pictures");

        if (!storageDir.exists()) storageDir.mkdirs();
        return File.createTempFile(fileName, ".jpg", storageDir);
    }

    private void uploadReport() {
        FirebaseUser currentUser = auth.getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "Not logged in.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (imageUris.isEmpty()) {
            Toast.makeText(this, "Add at least one image.", Toast.LENGTH_SHORT).show();
            return;
        }

        final String category = categoryField.getText().toString().trim();
        final String severity = severityField.getText().toString().trim();
        final String desc = descriptionField.getText().toString().trim();
        final String other = otherCategoryField.getText().toString().trim();

        if (TextUtils.isEmpty(category) || TextUtils.isEmpty(severity) || TextUtils.isEmpty(desc)) {
            Toast.makeText(this, "Please fill all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        final String finalCategory = category.equals("Other (Specify)") && !TextUtils.isEmpty(other) ? other : category;
        final String finalSeverity = severity;
        final String finalDesc = desc;
        final FirebaseUser finalUser = currentUser;

        android.app.ProgressDialog dialog = new android.app.ProgressDialog(this);
        dialog.setTitle("Submitting Report...");
        dialog.setCancelable(false);
        dialog.show();

        List<com.google.android.gms.tasks.Task<Uri>> uploadTasks = new ArrayList<>();


        for (Uri uri : imageUris) {
            final StorageReference ref = storageRef.child("reports/" + UUID.randomUUID() + ".jpg");
            com.google.android.gms.tasks.Task<Uri> task = ref.putFile(uri)
                    .continueWithTask(uploadTask -> {
                        if (!uploadTask.isSuccessful()) throw uploadTask.getException();
                        return ref.getDownloadUrl();
                    });
            uploadTasks.add(task);
        }


        com.google.android.gms.tasks.Tasks.whenAllSuccess(uploadTasks)
                .addOnSuccessListener(results -> {

                    List<String> urls = new ArrayList<>();
                    for (Object o : results) urls.add(o.toString());


                    firestore.collection("users")
                            .document(finalUser.getUid())
                            .get()
                            .addOnSuccessListener(userDoc -> {
                                String safeUsername;
                                if (userDoc.exists() && userDoc.contains("username")) {
                                    safeUsername = userDoc.getString("username");
                                } else {
                                    safeUsername = "Unknown User";
                                }


                                Map<String, Object> report = new HashMap<>();
                                report.put("category", finalCategory);
                                report.put("severity", finalSeverity);
                                report.put("description", finalDesc);
                                report.put("latitude", latitude);
                                report.put("longitude", longitude);
                                report.put("imageUrls", urls);
                                report.put("timestamp", Timestamp.now());
                                report.put("userId", finalUser.getUid());
                                report.put("username", safeUsername);
                                report.put("status", "Pending");
                                report.put("address", locationText.getText().toString());
                                report.put("addressStatus", "pending");


                                firestore.collection("Reports")
                                        .add(report)
                                        .addOnSuccessListener(docRef -> {
                                            dialog.dismiss();

                                            new Thread(() -> {
                                                try {
                                                    Geocoder geocoder = new Geocoder(ReportActivity.this, Locale.getDefault());
                                                    List<Address> addresses =
                                                            geocoder.getFromLocation(latitude, longitude, 1);

                                                    if (addresses != null && !addresses.isEmpty()) {
                                                        Address a = addresses.get(0);
                                                        String resolvedAddress =
                                                                (a.getLocality() != null)
                                                                        ? a.getLocality()
                                                                        : a.getAddressLine(0);

                                                        docRef.update(
                                                                "address", resolvedAddress,
                                                                "addressStatus", "resolved"
                                                        );
                                                    }
                                                } catch (Exception ignored) {}
                                            }).start();


                                            try {
                                                String adminId = "JL1f40vuHGOm4ldq2SsYF3HAgqV2";
                                                NotificationModel.sendNotification(
                                                        adminId,
                                                        docRef.getId(),
                                                        "New report submitted by " + safeUsername
                                                );
                                            } catch (Exception ignored) {}


                                            Intent i = new Intent(ReportActivity.this, Thankyouscreen.class);
                                            i.putExtra("category", finalCategory);
                                            i.putExtra("severity", finalSeverity);
                                            i.putExtra("location", locationText.getText().toString());
                                            i.putStringArrayListExtra("imageUrls", new ArrayList<>(urls));
                                            startActivity(i);

                                            new Handler().postDelayed(() -> ReportActivity.this.finish(), 300);
                                        })
                                        .addOnFailureListener(e -> {
                                            dialog.dismiss();
                                            Toast.makeText(ReportActivity.this,
                                                    "Failed to save report: " + e.getMessage(),
                                                    Toast.LENGTH_LONG).show();
                                        });

                            })
                            .addOnFailureListener(err -> {
                                dialog.dismiss();
                                Toast.makeText(ReportActivity.this,
                                        "Failed to fetch username: " + err.getMessage(),
                                        Toast.LENGTH_LONG).show();
                            });
                })
                .addOnFailureListener(err -> {
                    dialog.dismiss();
                    Toast.makeText(ReportActivity.this,
                            "Image upload failed: " + err.getMessage(),
                            Toast.LENGTH_LONG).show();
                });
    }

}
