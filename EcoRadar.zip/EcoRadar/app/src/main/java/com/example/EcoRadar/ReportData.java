package com.example.EcoRadar;

public class ReportData {

    public double latitude;
    public double longitude;
    public String category;
    public String severity;
    public String location;
    public String description;
    public String imageUrl;
    public String status;
    public String timestamp;


    public ReportData() {}

    public ReportData(double latitude, double longitude, String category, String severity,
                      String location, String description, String imageUrl,
                      String status, String timestamp) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.category = category;
        this.severity = severity;
        this.location = location;
        this.description = description;
        this.imageUrl = imageUrl;
        this.status = status;
        this.timestamp = timestamp;
    }
}
