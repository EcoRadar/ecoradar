package com.example.EcoRadar;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;

public class NotificationsFragment extends Fragment {

    private RecyclerView recyclerView;
    private NotificationsAdapter adapter;
    private ArrayList<NotificationModel> notifList = new ArrayList<>();

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_notifications, container, false);

        recyclerView = view.findViewById(R.id.recyclerNotifications);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new NotificationsAdapter(notifList, this::deleteNotification);
        recyclerView.setAdapter(adapter);

        loadNotifications();

        return view;
    }

    private void loadNotifications() {
        String currentUserId = FirebaseAuth.getInstance().getUid();

        if (currentUserId == null) return;

        FirebaseFirestore.getInstance()
                .collection("notifications")
                .whereEqualTo("recipientId", currentUserId)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) -> {

                    if (getContext() == null) return;

                    if (error != null) {
                        Log.e("NotifError", error.getMessage());
                        return;
                    }

                    notifList.clear();

                    if (value != null) {
                        for (var doc : value) {
                            NotificationModel notif = doc.toObject(NotificationModel.class);
                            notif.setId(doc.getId());
                            notifList.add(notif);
                        }
                    }

                    adapter.notifyDataSetChanged();
                });
    }

    private void deleteNotification(String notifId) {
        if (notifId == null) return;

        FirebaseFirestore.getInstance()
                .collection("notifications")
                .document(notifId)
                .delete()
                .addOnSuccessListener(aVoid ->
                        Toast.makeText(getContext(), "Notification deleted", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "Failed to delete: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
