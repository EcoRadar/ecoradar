package com.example.EcoRadar;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {

    private static final String TAG = "Register";

    private EditText editTextEmail, editTextPassword, editTextUsername, editTextPhone;
    private Button buttonRegister;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        editTextEmail = findViewById(R.id.email);
        editTextPassword = findViewById(R.id.password);
        editTextUsername = findViewById(R.id.username);
        editTextPhone = findViewById(R.id.phone);
        buttonRegister = findViewById(R.id.registerButton);

        buttonRegister.setOnClickListener(v -> handleRegisterClick());
    }

    private void handleRegisterClick() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String username = editTextUsername.getText().toString().trim();
        String phone = editTextPhone.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty() || username.isEmpty() || phone.isEmpty()) {
            showCustomPopup("Registration Error", "Please fill all fields.", null);
            return;
        }

        if (password.length() < 6) {
            showCustomPopup("Registration Error", "Password must be at least 6 characters.", null);
            return;
        }

        if (password.length() > 20) {
            showCustomPopup("Registration Error", "Password cannot be more than 20 characters.", null);
            return;
        }

        registerUser(email, password, username, phone);
    }

    private void registerUser(String email, String password, String username, String phone) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();

                        if (user != null) {
                            saveUserProfile(user, username, phone, email);
                        }

                        showCustomPopup(
                                "Registration Successful",
                                "Welcome " + email + "!",
                                () -> {
                                    startActivity(new Intent(this, MainMenu.class));
                                    finish();
                                }
                        );

                    } else {
                        String message = task.getException() != null
                                ? task.getException().getMessage()
                                : "Registration failed";

                        showCustomPopup("Registration Error", message, null);
                        Log.e(TAG, "Registration error", task.getException());
                    }
                });
    }

    private void saveUserProfile(FirebaseUser user, String username, String phone, String email) {
        Map<String, Object> userData = new HashMap<>();
        userData.put("username", username);
        userData.put("phone", phone);
        userData.put("email", email);
        userData.put("role", "user");
        userData.put("createdAt", Timestamp.now());

        db.collection("users").document(user.getUid())
                .set(userData)
                .addOnSuccessListener(aVoid ->
                        Log.d(TAG, "User profile saved: " + user.getUid()))
                .addOnFailureListener(e -> {
                    Log.w(TAG, "Error saving user profile", e);
                    showCustomPopup("Registration Error", "Failed to save user profile.", null);
                });
    }


    private void showCustomPopup(String title, String message, Runnable onOk) {
        View popupView = LayoutInflater.from(this).inflate(R.layout.custom_popup, null);

        TextView popupTitle = popupView.findViewById(R.id.popupTitle);
        TextView popupMessage = popupView.findViewById(R.id.popupMessage);
        Button popupButton = popupView.findViewById(R.id.popupButton);

        popupTitle.setText(title);
        popupMessage.setText(message);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(popupView)
                .setCancelable(false)
                .create();

        popupButton.setOnClickListener(v -> {
            dialog.dismiss();
            if (onOk != null) onOk.run();
        });

        dialog.show();
    }
}
