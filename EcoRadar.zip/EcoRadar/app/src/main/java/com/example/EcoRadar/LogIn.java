package com.example.EcoRadar;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseUser;

public class LogIn extends AppCompatActivity {

    private static final String TAG = "LogIn";

    private EditText emailField, passwordField;
    private Button loginButton;
    private TextView registerText;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();

        emailField = findViewById(R.id.username);
        passwordField = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        registerText = findViewById(R.id.registertext);

        loginButton.setOnClickListener(v -> handleLoginClick());
        registerText.setOnClickListener(v -> openRegister());
    }

    private void handleLoginClick() {
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            showCustomPopup("Login Error", "Please fill all fields.", null);
            return;
        }

        loginUser(email, password);
    }

    private void openRegister() {
        startActivity(new Intent(this, Register.class));
    }

    private void loginUser(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {


                    if (isFinishing() || isDestroyed()) return;

                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();

                        showCustomPopup(
                                "Login Successful",
                                "Welcome " + (user != null ? user.getEmail() : "") + "!",
                                () -> {
                                    startActivity(new Intent(LogIn.this, MainMenu.class));
                                    finish();
                                }
                        );

                    } else {
                        String message;

                        if (task.getException() instanceof FirebaseAuthInvalidUserException) {
                            message = "Email not found. Please try again.";
                        } else if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                            if (password.length() < 6) {
                                message = "Password must be at least 6 characters.";
                            } else {
                                message = "Wrong password. Try again.";
                            }
                        } else {
                            message = "Login failed. Please try again.";
                        }

                        showCustomPopup("Login Error", message, null);
                        Log.e(TAG, "Login error", task.getException());
                    }
                });
    }


    private void showCustomPopup(String title, String message, Runnable onOk) {


        if (isFinishing() || isDestroyed()) return;

        View popupView = LayoutInflater.from(LogIn.this)
                .inflate(R.layout.custom_popup, null);

        TextView popupTitle = popupView.findViewById(R.id.popupTitle);
        TextView popupMessage = popupView.findViewById(R.id.popupMessage);
        Button popupButton = popupView.findViewById(R.id.popupButton);

        popupTitle.setText(title);
        popupMessage.setText(message);

        AlertDialog dialog = new AlertDialog.Builder(LogIn.this)
                .setView(popupView)
                .setCancelable(false)
                .create();

        popupButton.setOnClickListener(v -> {
            if (!isFinishing() && !isDestroyed()) {
                dialog.dismiss();
            }
            if (onOk != null) {
                onOk.run();
            }
        });

        dialog.show();
    }
}
