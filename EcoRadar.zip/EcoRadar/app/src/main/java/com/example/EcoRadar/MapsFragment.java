package com.example.EcoRadar;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MapsFragment extends Fragment implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FirebaseFirestore db;
    private String currentUserId;
    private final HashMap<String, Marker> activeMarkers = new HashMap<>();
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();

    private FusedLocationProviderClient fusedLocation;
    private LocationCallback locationCallback;
    private boolean firstLocationUpdate = true;

    private static final int LOCATION_PERMISSION_CODE = 5001;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable android.view.ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.maps_fragment, container, false);
        db = FirebaseFirestore.getInstance();

        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            return view;
        }

        currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        fusedLocation = LocationServices.getFusedLocationProviderClient(requireActivity());

        SupportMapFragment mapFragment =
                (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);

        if (mapFragment != null) mapFragment.getMapAsync(this);

        return view;
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(7.1907, 125.4553), 12));

        enableLocationFeature();

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            startRealtimeUserReports();
        }

        mMap.setOnMarkerClickListener(marker -> {
            Object tag = marker.getTag();
            if (tag instanceof HashMap<?, ?>) {
                @SuppressWarnings("unchecked")
                HashMap<String, Object> data = (HashMap<String, Object>) tag;
                Object imgObj = data.get("imageUrls");
                List<String> images = new ArrayList<>();
                if (imgObj instanceof List<?>) {
                    for (Object obj : (List<?>) imgObj) {
                        if (obj instanceof String) images.add((String) obj);
                    }
                }
                showImagesBottomSheet(images, data);
            }
            return false;
        });
    }


    private void enableLocationFeature() {
        if (ContextCompat.checkSelfPermission(requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_CODE
            );
            return;
        }

        if (mMap != null) {
            mMap.setMyLocationEnabled(true);
        }

        startLocationUpdates();
    }

    private void startLocationUpdates() {

        LocationRequest request = LocationRequest.create()
                .setInterval(2000)
                .setFastestInterval(1000)
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                if (locationResult.getLastLocation() == null) return;

                double lat = locationResult.getLastLocation().getLatitude();
                double lng = locationResult.getLastLocation().getLongitude();

                LatLng myLocation = new LatLng(lat, lng);

                if (firstLocationUpdate) {
                    firstLocationUpdate = false;
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(myLocation, 16));
                }
            }
        };

        fusedLocation.requestLocationUpdates(request, locationCallback, Looper.getMainLooper());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == LOCATION_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableLocationFeature();
            } else {
                Toast.makeText(requireContext(), "Location permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
    }


    private void startRealtimeUserReports() {

        if (FirebaseAuth.getInstance().getCurrentUser() == null) return;

        db.collection("Reports")
                .whereEqualTo("userId", currentUserId)
                .addSnapshotListener((snapshots, error) -> {

                    if (getContext() == null) return;

                    if (error != null || snapshots == null) return;

                    for (DocumentChange dc : snapshots.getDocumentChanges()) {
                        DocumentSnapshot doc = dc.getDocument();
                        String id = doc.getId();

                        switch (dc.getType()) {
                            case ADDED:
                                addMarker(doc, id);
                                break;
                            case MODIFIED:
                                updateMarker(doc, id);
                                break;
                            case REMOVED:
                                removeMarker(id);
                                break;
                        }
                    }
                });
    }



    private void addMarker(DocumentSnapshot doc, String id) {
        if (mMap == null) return;

        String status = doc.getString("status");
        if (status != null && status.equalsIgnoreCase("Resolved")) {

            removeMarker(id);
            return;
        }

        Double lat = doc.getDouble("latitude");
        Double lng = doc.getDouble("longitude");
        if (lat == null || lng == null) return;

        String category = doc.getString("category");
        String severity = doc.getString("severity");
        String description = doc.getString("description");

        List<String> imageUrls = new ArrayList<>();
        Object imagesObj = doc.get("imageUrls");
        if (imagesObj instanceof List<?>) {
            for (Object obj : (List<?>) imagesObj) {
                if (obj instanceof String) imageUrls.add((String) obj);
            }
        }

        LatLng position = new LatLng(lat, lng);
        BitmapDescriptor icon = getMarkerColor(severity, status);

        Marker marker = mMap.addMarker(new MarkerOptions()
                .position(position)
                .title(category)
                .snippet("Loading address...")
                .icon(icon)
        );

        if (marker != null) {
            HashMap<String, Object> markerData = new HashMap<>();
            markerData.put("imageUrls", imageUrls);
            markerData.put("category", category);
            markerData.put("severity", severity);
            markerData.put("description", description);
            markerData.put("status", status);
            marker.setTag(markerData);

            activeMarkers.put(id, marker);

            executorService.execute(() -> {
                String address = getAddressFromLatLng(lat, lng);
                markerData.put("address", address);

                if (getActivity() != null) {
                    getActivity().runOnUiThread(() -> marker.setSnippet(
                            "Status: " + status +
                                    "\nSeverity: " + severity +
                                    "\nLocation: " + address
                    ));
                }
            });
        }
    }



    private void updateMarker(DocumentSnapshot doc, String id) {
        String status = doc.getString("status");
        if (status != null && status.equalsIgnoreCase("Resolved")) {

            removeMarker(id);
        } else {

            removeMarker(id);
            addMarker(doc, id);
        }
    }

    private void removeMarker(String id) {
        Marker m = activeMarkers.remove(id);
        if (m != null) m.remove();
    }

    private String getAddressFromLatLng(double lat, double lng) {
        try {
            if (getContext() == null) return "Unknown Location";
            Geocoder geocoder = new Geocoder(getContext(), Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
            if (addresses != null && !addresses.isEmpty()) {
                String city = addresses.get(0).getLocality();
                return (city != null) ? city : addresses.get(0).getAddressLine(0);
            }
        } catch (IOException ignored) {}
        return "Unknown Location";
    }

    private BitmapDescriptor getMarkerColor(String severity, String status) {

        if (status != null && status.equalsIgnoreCase("In Review")) {
            return BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE);
        }

        if (severity == null) {
            return BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE);
        }

        switch (severity.toLowerCase()) {
            case "high":
            case "urgent":
                return BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED);
            case "moderate":
                return BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE);
            case "low":
                return BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN);
            default:
                return BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE);
        }
    }


    private void showImagesBottomSheet(List<String> images, HashMap<String, Object> data) {
        if (getContext() == null) return;

        View view = getLayoutInflater().inflate(R.layout.bottom_sheet_images, null);

        TextView title = view.findViewById(R.id.title_text);
        TextView severity = view.findViewById(R.id.severity_text);
        TextView status = view.findViewById(R.id.status_text);
        TextView description = view.findViewById(R.id.description_text);
        RecyclerView recycler = view.findViewById(R.id.images_recycler);

        title.setText((String) data.get("category"));
        severity.setText("Severity: " + data.get("severity"));

        String stat = (String) data.get("status");
        status.setText("Status: " + (stat != null ? stat : "pending"));

        description.setText((String) data.get("description"));

        if (images.isEmpty()) {
            recycler.setVisibility(View.GONE);
        } else {
            recycler.setLayoutManager(new LinearLayoutManager(getContext(),
                    LinearLayoutManager.HORIZONTAL, false));
            recycler.setAdapter(new ReportImagesAdapter(getContext(), images));
        }

        BottomSheetDialog dialog = new BottomSheetDialog(getContext());
        dialog.setContentView(view);
        dialog.show();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        executorService.shutdownNow();
        if (fusedLocation != null && locationCallback != null) {
            fusedLocation.removeLocationUpdates(locationCallback);
        }
    }
}
