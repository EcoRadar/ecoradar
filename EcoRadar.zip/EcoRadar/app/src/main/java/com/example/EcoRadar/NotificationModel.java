package com.example.EcoRadar;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class NotificationModel {

    private String id;
    private String message;
    private String recipientId;
    private String reportId;
    private String status;
    private Timestamp timestamp;

    public NotificationModel() {}

    public NotificationModel(String id, String message, String recipientId, String reportId, String status, Timestamp timestamp) {
        this.id = id;
        this.message = message;
        this.recipientId = recipientId;
        this.reportId = reportId;
        this.status = status;
        this.timestamp = timestamp;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getRecipientId() { return recipientId; }
    public void setRecipientId(String recipientId) { this.recipientId = recipientId; }

    public String getReportId() { return reportId; }
    public void setReportId(String reportId) { this.reportId = reportId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Timestamp getTimestamp() { return timestamp; }
    public void setTimestamp(Timestamp timestamp) { this.timestamp = timestamp; }


    public static void sendNotification(String recipientId, String reportId, String messageText) {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();

        Map<String, Object> notif = new HashMap<>();
        notif.put("recipientId", recipientId);
        notif.put("reportId", reportId);
        notif.put("message", messageText);
        notif.put("status", "unread");
        notif.put("timestamp", Timestamp.now());

        firestore.collection("notifications")
                .add(notif);
    }
}
