package com.example.EcoRadar;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class Maps extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private LocationCallback locationCallback;

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 100;

    private TextView addressText;
    private ImageView backButton, nextButton;
    private Marker currentLocationMarker;

    private double currentLat = 0.0;
    private double currentLng = 0.0;
    private String currentAddress = "";

    private boolean hasShownTapReminder = false;
    private boolean locationDialogShown = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        addressText = findViewById(R.id.addressText);
        backButton = findViewById(R.id.backButton);
        nextButton = findViewById(R.id.nextButton);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) mapFragment.getMapAsync(this);

        backButton.setOnClickListener(v -> finish());
        nextButton.setOnClickListener(v -> showLocationConfirmationDialog());
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setMyLocationButtonEnabled(true);

        checkLocationEnabled();

        if (!hasShownTapReminder) {
            Snackbar.make(findViewById(android.R.id.content),
                            "Tap anywhere on the map to mark your location.",
                            Snackbar.LENGTH_INDEFINITE)
                    .setAction("Got it", v -> {})
                    .setAnchorView(nextButton)
                    .show();
            hasShownTapReminder = true;
        }


        mMap.setOnMapClickListener(latLng -> {
            if (currentLocationMarker != null) currentLocationMarker.remove();

            currentLocationMarker = mMap.addMarker(new MarkerOptions()
                    .position(latLng)
                    .title("Selected Location"));

            currentLat = latLng.latitude;
            currentLng = latLng.longitude;

            updateAddressAsync(currentLat, currentLng);
            showLocationConfirmationDialog();
        });
    }


    private void startLocationUpdates() {
        LocationRequest request = LocationRequest.create()
                .setInterval(2000)
                .setFastestInterval(1000)
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                if (locationResult.getLastLocation() == null) return;

                Location loc = locationResult.getLastLocation();
                currentLat = loc.getLatitude();
                currentLng = loc.getLongitude();
                LatLng latLng = new LatLng(currentLat, currentLng);


                if (currentLocationMarker == null) {
                    currentLocationMarker = mMap.addMarker(new MarkerOptions()
                            .position(latLng)
                            .title("Your Location"));
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 17));
                } else {
                    currentLocationMarker.setPosition(latLng);
                }

                updateAddressAsync(currentLat, currentLng);
            }
        };

        fusedLocationProviderClient.requestLocationUpdates(request, locationCallback, Looper.getMainLooper());
    }

    private void enableLocationAndShowCurrent() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        if (mMap != null) mMap.setMyLocationEnabled(true);
        startLocationUpdates();
    }

    private void updateAddressAsync(double lat, double lng) {
        new Thread(() -> {
            String address = getAddressFromLocation(lat, lng);
            runOnUiThread(() -> {
                currentAddress = address.isEmpty() ? "Address not found" : address;
                addressText.setText(currentAddress);
            });
        }).start();
    }

    private String getAddressFromLocation(double lat, double lng) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);
                StringBuilder sb = new StringBuilder();
                if (address.getThoroughfare() != null) sb.append(address.getThoroughfare()).append(", ");
                if (address.getLocality() != null) sb.append(address.getLocality()).append(", ");
                if (address.getAdminArea() != null) sb.append(address.getAdminArea()).append(", ");
                if (address.getCountryName() != null) sb.append(address.getCountryName());
                return sb.toString();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }


    private void showLocationConfirmationDialog() {
        String displayAddress = currentAddress.isEmpty() ? "Resolving address..." : currentAddress;

        new MaterialAlertDialogBuilder(this)
                .setTitle("Confirm Location")
                .setMessage(
                        "Is this your correct location?\n\n" +
                                "Coordinates:\n" +
                                currentLat + ", " + currentLng + "\n\n" +
                                "Address:\n" +
                                displayAddress
                )
                .setCancelable(false)
                .setPositiveButton("Yes", (dialog, which) -> {
                    Intent intent = new Intent(Maps.this, ReportActivity.class);
                    intent.putExtra("latitude", currentLat);
                    intent.putExtra("longitude", currentLng);
                    intent.putExtra("address", displayAddress);
                    startActivity(intent);
                    finish();
                })
                .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                .show();
    }


    private void checkLocationEnabled() {
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        boolean gpsEnabled = false;
        boolean networkEnabled = false;
        try {
            gpsEnabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
            networkEnabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception ignored) {}

        if (!gpsEnabled && !networkEnabled) {
            if (!locationDialogShown) {
                locationDialogShown = true;
                new MaterialAlertDialogBuilder(this)
                        .setTitle("Location Required")
                        .setMessage("Location services are turned off. Please enable GPS or network location to continue.")
                        .setCancelable(false)
                        .setPositiveButton("Enable", (dialog, which) -> {
                            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> {
                            Toast.makeText(this, "Location is required to use the map.", Toast.LENGTH_SHORT).show();
                            finish();
                        })
                        .show();
            }
        } else {
            enableLocationAndShowCurrent();
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableLocationAndShowCurrent();
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (lm != null && (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
                || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))) {
            enableLocationAndShowCurrent();
        } else {
            checkLocationEnabled();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (fusedLocationProviderClient != null && locationCallback != null) {
            fusedLocationProviderClient.removeLocationUpdates(locationCallback);
        }
    }
}
