package com.example.EcoRadar;

import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ReportViewHolder> {

    private final List<Report> reportList;
    private final Context context;

    public ReportAdapter(Context context, List<Report> reportList) {
        this.context = context;
        this.reportList = reportList != null ? reportList : new ArrayList<>();
    }

    @NonNull
    @Override
    public ReportViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_report_card, parent, false);
        return new ReportViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReportViewHolder holder, int position) {
        Report report = reportList.get(position);
        if (report == null) return;

        try {
            holder.category.setText(report.getCategory());
            holder.severity.setText("Severity: " + report.getSeverity());


            if (report.getStatus() != null) {
                if (report.getStatus().equalsIgnoreCase("Pending")) {
                    holder.status.setText("Pending");
                    holder.status.setBackgroundResource(R.drawable.bg_status_pending);
                } else if (report.getStatus().equalsIgnoreCase("In Review")) {
                    holder.status.setText("In Review");
                    holder.status.setBackgroundResource(R.drawable.bg_status_review);
                } else {
                    holder.status.setText(report.getStatus());
                    holder.status.setBackgroundResource(R.drawable.bg_status_pending);
                }
            } else {
                holder.status.setText("Pending");
                holder.status.setBackgroundResource(R.drawable.bg_status_pending);
            }

            if (report.getLatitude() != null && report.getLongitude() != null
                    && report.getLatitude() != 0 && report.getLongitude() != 0) {
                holder.location.setText(getAddressFromLatLng(report.getLatitude(), report.getLongitude()));
            } else {
                holder.location.setText("Unknown location");
            }

            if (report.getTimestamp() != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy • hh:mm a", Locale.getDefault());
                holder.time.setText("Reported: " + sdf.format(report.getTimestamp().toDate()));
            } else {
                holder.time.setText("Reported: --");
            }


            if (report.getImageUrls() != null && !report.getImageUrls().isEmpty()) {
                Glide.with(context)
                        .load(report.getImageUrls().get(0))
                        .placeholder(R.drawable.user_placeholder)
                        .error(R.drawable.user_placeholder)
                        .centerCrop()
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .into(holder.image);
            } else {
                holder.image.setImageResource(R.drawable.user_placeholder);
            }

            holder.itemView.setOnClickListener(v -> {
                Intent intent = new Intent(context, Thankyouscreen.class);
                intent.putExtra("category", report.getCategory());
                intent.putExtra("severity", report.getSeverity());
                intent.putExtra("location", holder.location.getText().toString());
                intent.putExtra("status", report.getStatus());
                intent.putStringArrayListExtra("imageUrls", new ArrayList<>(report.getImageUrls()));
                context.startActivity(intent);
            });

        } catch (Exception e) {
            Log.e("ReportAdapter", "Error binding report item", e);
        }
    }

    @Override
    public int getItemCount() {
        return reportList.size();
    }



    public void addReport(Report report) {
        reportList.add(0, report);
        notifyItemInserted(0);
    }

    public void updateReport(Report updatedReport) {
        if (updatedReport.getDocumentId() == null) return;
        for (int i = 0; i < reportList.size(); i++) {
            Report existing = reportList.get(i);
            if (existing.getDocumentId() != null &&
                    existing.getDocumentId().equals(updatedReport.getDocumentId())) {
                reportList.set(i, updatedReport);
                notifyItemChanged(i);
                return;
            }
        }
    }

    public void removeReport(String documentId) {
        if (documentId == null) return;
        for (int i = 0; i < reportList.size(); i++) {
            Report existing = reportList.get(i);
            if (existing.getDocumentId() != null &&
                    existing.getDocumentId().equals(documentId)) {
                reportList.remove(i);
                notifyItemRemoved(i);
                return;
            }
        }
    }



    static class ReportViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView category, severity, location, time, status;

        public ReportViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.reportImage);
            category = itemView.findViewById(R.id.reportCategory);
            severity = itemView.findViewById(R.id.reportSeverity);
            location = itemView.findViewById(R.id.reportLocation);
            time = itemView.findViewById(R.id.reportTime);
            status = itemView.findViewById(R.id.txtStatus);
        }
    }



    private String getAddressFromLatLng(double lat, double lng) {
        Geocoder geocoder = new Geocoder(context, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);
                String city = address.getLocality() != null ? address.getLocality() : "";
                String state = address.getAdminArea() != null ? address.getAdminArea() : "";
                String country = address.getCountryName() != null ? address.getCountryName() : "";
                String result = (city + ", " + state + ", " + country).replaceAll("^, |, $", "");
                return result.isEmpty() ? "Unknown location" : result;
            }
        } catch (IOException e) {
            Log.e("ReportAdapter", "Geocoder failed", e);
        }
        return "Unknown location";
    }
}
